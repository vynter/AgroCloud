package com.backend.yogesh.Service.Implements;

import java.util.List;
import java.util.stream.Collectors;
import org.springframework.stereotype.Service;

import com.backend.yogesh.model.Theme;
import com.backend.yogesh.repository.ThemeRepository;
import com.backend.yogesh.dto.response.BasicResponse;
import com.backend.yogesh.dto.response.ThemeResponse;
import com.backend.yogesh.Service.ThemeService;
import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class ThemeImpl implements ThemeService {
    private final ThemeRepository LoanRepo;

    @Override
    public BasicResponse<ThemeResponse> getAllTheme() 
    {
        List<Theme> Loans = LoanRepo.findAll();
        List<ThemeResponse> LoanResponses = Loans.stream()
            .map(Loan -> ThemeResponse.builder()
                .themeId(Loan.getThemeid())
                .themeName(Loan.getTheme())
                .build())
            .collect(Collectors.toList());
        return BasicResponse.<ThemeResponse>builder()
            .message("success!")
            .data(LoanResponses)
            .build();
    }
}