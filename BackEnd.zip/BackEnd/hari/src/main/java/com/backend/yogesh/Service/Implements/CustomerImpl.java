package com.backend.yogesh.Service.Implements;

import java.util.List;
import java.util.stream.Collectors;
import org.springframework.stereotype.Service;

import com.backend.yogesh.model.Customer;
// import com.backend.yogesh.model.Loan;
import com.backend.yogesh.repository.CustomerRepository;
// import com.backend.yogesh.repository.LRepository;
import com.backend.yogesh.Service.CustomerService;
// import com.backend.yogesh.Service.LoanService;
import com.backend.yogesh.dto.request.CustomerRequest;
// import com.backend.yogesh.dto.request.LoanRequest;
// import com.backend.yogesh.dto.request.LoanRequest;
import com.backend.yogesh.dto.response.BasicResponse;
import com.backend.yogesh.dto.response.CustomerResponse;
// import com.backend.yogesh.dto.response.CustomerResponse;

// import com.backend.yogesh.dto.response.LoanResponse;
import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class CustomerImpl implements CustomerService {
    private final CustomerRepository customerRepository;

    @Override
public BasicResponse<CustomerResponse> getAllCustomer() {
    List<Customer> customers = customerRepository.findAll();
    List<CustomerResponse> customerResponses = customers.stream()
        .map(customer -> CustomerResponse.builder()
            .customerId(customer.getCustomerId())
            .firstname(customer.getFirstname())
            .lastname(customer.getLastname())
            .place(customer.getPlace())
            .aadharnumber(customer.getAadharnumber())
            .type(customer.getType())
            .loanamount(customer.getLoanamount())
            .phnumber(customer.getPhnumber())
            .income(customer.getIncome())
            // .user(customer.getUser())
            .build())
        .collect(Collectors.toList());
    return BasicResponse.<CustomerResponse>builder()
        .message("success!")
        .data(customerResponses)
        .build();
}

    @Override
    public CustomerResponse createCustomer (CustomerRequest request) {
        Customer customer = Customer.builder()
            .firstname(request.getFirstname())
            .lastname(request.getLastname())
            .place(request.getPlace())
            .aadharnumber(request.getAadharnumber())
            .type(request.getType())
            .loanamount(request.getLoanamount())
            .phnumber(request.getPhnumber())
            .income(request.getIncome())
            // .user(request.getUser())
            .build();
            customerRepository.save(customer);
        return CustomerResponse.builder()
            .message("Customer created successfully")
            .build();
}
}