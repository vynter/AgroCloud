package com.backend.yogesh.dto.response;

import java.util.List;
import java.util.Collections; 

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import com.backend.yogesh.model.Loan;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class LoanResponse {
    private String message;
    private String id;
    private String Loan_name;
    private String Loan_price;
    private String Loan_image;
    private String Loan_rating;
    private String Loan_category;
    private String Loan_desc;
    private Loan data;
}
