package com.backend.yogesh.Service;

import com.backend.yogesh.dto.request.CustomerRequest;
import com.backend.yogesh.dto.request.CustomerRequest;
import com.backend.yogesh.dto.response.BasicResponse;
import com.backend.yogesh.dto.response.CustomerResponse;
import com.backend.yogesh.dto.response. CustomerResponse;

public interface CustomerService {
    BasicResponse<CustomerResponse> getAllCustomer();
     CustomerResponse createCustomer(CustomerRequest request);
    
}
